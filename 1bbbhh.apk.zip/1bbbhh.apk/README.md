# Smart Driver Companion (Arsitektur OSM + Cloudflare API)

Template proyek Android (Kotlin) dan Backend Serverless (Cloudflare Workers) yang mereplikasi arsitektur jaringan dari tangkapan `PCAPdroid` secara aman, mandiri, dan gratis:

1. **Peta OpenStreetMap (`osmdroid`)**: Mengambil gambar peta langsung dari `tile.openstreetmap.org` (Fastly CDN) tanpa perlu kartu kredit atau API Key Google Maps.
2. **Backend API di Balik Cloudflare (`worker.js`)**: Kode server API yang bisa dipasang pada domain `.my.id` menggunakan Cloudflare Custom Domains sehingga alamat IP server asli terlindungi oleh jaringan proxy Cloudflare (seperti IP `104.21.53.88`).
3. **Klien Jaringan `OkHttp` + DNS-over-HTTPS (`1.1.1.1`) & Siklus Heartbeat 30 Detik**: Mengatur resolusi DNS lewat Cloudflare `1.1.1.1` port 443 serta siklus pengecekan latensi/ping otomatis setiap 30 detik.
4. **Nama Paket Netral (`com.fajhru.smartdriveraide`)**: Menghindari kata kunci mencurigakan seperti `mod`, `gacor`, atau `taxsee` agar aman di perangkat Anda.
