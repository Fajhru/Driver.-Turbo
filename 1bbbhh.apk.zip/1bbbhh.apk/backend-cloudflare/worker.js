/**
 * Cloudflare Worker untuk Backend API (seperti api.modtaxseedriver.my.id di balik IP 104.21.53.88)
 * Deploy gratis di Cloudflare Workers dan hubungkan ke Custom Domain (.my.id)
 */
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (request.method === "POST" && url.pathname === "/v1/sync") {
      try {
        const body = await request.json();
        const deviceId = body.device_id || "unknown";
        const filterKeywords = body.filter_keywords || "";

        // Contoh validasi lisensi perangkat & pengembalian konfigurasi filter
        const responsePayload = {
          status: "active",
          vip_member: true,
          device_id: deviceId,
          applied_filters: filterKeywords.split(",").map(s => s.trim()).filter(Boolean),
          recommended_zones: [
            { name: "Pusat Kota Padang", lat: -0.9471, lng: 100.4172 },
            { name: "Stasiun Padang", lat: -0.9416, lng: 100.3632 }
          ],
          server_time: new Date().toISOString()
        };

        return new Response(JSON.stringify(responsePayload), {
          status: 200,
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
          }
        });
      } catch (err) {
        return new Response(JSON.stringify({ status: "error", message: err.message }), {
          status: 400,
          headers: { "Content-Type": "application/json" }
        });
      }
    }

    return new Response(JSON.stringify({ service: "SmartDriver API Gateway", status: "online" }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  }
};
