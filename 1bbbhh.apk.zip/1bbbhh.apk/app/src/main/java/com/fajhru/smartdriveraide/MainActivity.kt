package com.fajhru.smartdriveraide

import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

class MainActivity : AppCompatActivity() {

    private lateinit var mapView: MapView
    private lateinit var tvStatus: TextView
    private lateinit var etKeywords: EditText
    private var heartbeatJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Wajib bagi kebijakan tile.openstreetmap.org (Fastly CDN) agar tidak diblokir
        Configuration.getInstance().userAgentValue = packageName

        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        etKeywords = findViewById(R.id.etKeywords)
        mapView = findViewById(R.id.mapView)

        setupOpenStreetMap()

        findViewById<Button>(R.id.btnSyncConfig).setOnClickListener {
            val keywords = etKeywords.text.toString().trim()
            val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
            tvStatus.text = "Status: Menghubungi API Cloudflare..."
            lifecycleScope.launch(Dispatchers.IO) {
                val result = runCatching {
                    NetworkEngine.syncConfigWithBackend(androidId, keywords)
                }.getOrElse { "Gagal: ${it.localizedMessage}" }

                withContext(Dispatchers.Main) {
                    tvStatus.text = "Respon API: $result"
                }
            }
        }

        val btnHeartbeat = findViewById<Button>(R.id.btnToggleHeartbeat)
        btnHeartbeat.setOnClickListener {
            if (heartbeatJob?.isActive == true) {
                heartbeatJob?.cancel()
                btnHeartbeat.text = "Mulai Ping 30d"
                tvStatus.text = "Status: Heartbeat dihentikan"
            } else {
                btnHeartbeat.text = "Stop Ping 30d"
                startPeriodicHeartbeat()
            }
        }
    }

    private fun setupOpenStreetMap() {
        // Memakai tile.openstreetmap.org seperti di log PCAPdroid
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)

        // Titik awal default: Kota Padang, Sumatera Barat (-0.9471, 100.4172)
        val startPoint = GeoPoint(-0.9471, 100.4172)
        mapView.controller.setZoom(14.5)
        mapView.controller.setCenter(startPoint)

        val marker = Marker(mapView).apply {
            position = startPoint
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            title = "Titik Pantau Utama (Kota Padang)"
        }
        mapView.overlays.add(marker)
    }

    private fun startPeriodicHeartbeat() {
        heartbeatJob = lifecycleScope.launch(Dispatchers.IO) {
            while (isActive) {
                val pingMs = runCatching {
                    NetworkEngine.checkEndpointLatency("1.1.1.1", 443)
                }.getOrDefault(-1L)

                withContext(Dispatchers.Main) {
                    tvStatus.text = if (pingMs >= 0) {
                        "Status: Aktif | Ping TLS 443: ${pingMs}ms (siklus 30 detik)"
                    } else {
                        "Status: Koneksi terputus"
                    }
                }
                delay(30_000L) // Siklus tepat 30 detik seperti di log PCAPdroid
            }
        }
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }
}
