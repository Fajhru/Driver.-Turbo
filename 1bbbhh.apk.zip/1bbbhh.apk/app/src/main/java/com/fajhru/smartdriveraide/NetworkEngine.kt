package com.fajhru.smartdriveraide

import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.dnsoverhttps.DnsOverHttps
import org.json.JSONObject
import java.net.InetAddress
import java.util.concurrent.TimeUnit
import javax.net.SocketFactory

/**
 * NetworkEngine mereplikasi arsitektur jaringan dari log PCAPdroid:
 * 1. Resolusi DNS terenkripsi lewat Cloudflare 1.1.1.1 (port 443 TLS)
 * 2. Sinkronisasi lisensi & filter ke backend pribadi di balik Cloudflare (HTTPS/QUIC)
 * 3. Pengecekan latensi/heartbeat TCP/TLS periodik setiap 30 detik
 */
object NetworkEngine {

    // Ganti dengan domain Cloudflare Workers / Custom Domain milik Anda (.my.id / .workers.dev)
    private const val BACKEND_API_URL = "https://divine-band-c367.fajhrurahman.workers.dev/v1/sync"

    private val bootstrapClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    // Menggunakan Cloudflare DNS 1.1.1.1 via HTTPS (DoH) seperti trafik 1.1.1.1:443 di PCAPdroid
    private val cloudflareDoh: Dns = DnsOverHttps.Builder()
        .client(bootstrapClient)
        .url("https://1.1.1.1/dns-query".toHttpUrl())
        .bootstrapDnsHosts(
            InetAddress.getByName("1.1.1.1"),
            InetAddress.getByName("1.0.0.1")
        )
        .build()

    val httpClient: OkHttpClient = bootstrapClient.newBuilder()
        .dns(cloudflareDoh)
        .build()

    fun syncConfigWithBackend(deviceId: String, keywordFilter: String): String {
        val payload = JSONObject().apply {
            put("device_id", deviceId)
            put("filter_keywords", keywordFilter)
            put("timestamp", System.currentTimeMillis())
        }
        val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(BACKEND_API_URL)
            .header("User-Agent", "SmartDriverCompanion/1.0 (Android)")
            .post(body)
            .build()

        httpClient.newCall(request).execute().use { response ->
            return if (response.isSuccessful) {
                response.body?.string() ?: "{\"status\":\"ok\"}"
            } else {
                "HTTP ${response.code}"
            }
        }
    }

    /**
     * Melakukan pengecekan latensi TLS (heartbeat) setiap 30 detik
     */
    fun checkEndpointLatency(host: String = "1.1.1.1", port: Int = 443): Long {
        val start = System.currentTimeMillis()
        SocketFactory.getDefault().createSocket(host, port).use { socket ->
            socket.soTimeout = 5000
        }
        return System.currentTimeMillis() - start
    }
}
